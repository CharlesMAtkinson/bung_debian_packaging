# Start of ~/.bashrc.d/aliases.bung.sh

# Bash scrippet to set aliases for bung
# Intended to be sourced from ~/.bashrc

alias ebb='cd /etc/bung && lrt'
alias vlb='cd /var/log/bung && lrt'

# End of ~/.bashrc.d/aliases.bung.sh
